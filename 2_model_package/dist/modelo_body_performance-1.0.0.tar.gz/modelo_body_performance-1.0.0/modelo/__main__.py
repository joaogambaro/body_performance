from modelo.treina_modelo import treina_pipeline

def main():
    print("Rodar:")
    print("--> python -m modelo.treina_modelo, para treinar o modelo")
    print("--> python -m modelo.preve_modelo, para prever com o modelo")



#entry point
if __name__=="__main__":
    main()
